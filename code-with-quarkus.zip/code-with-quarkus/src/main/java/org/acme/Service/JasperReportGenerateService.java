package org.acme.Service;

import net.sf.jasperreports.engine.*;

import javax.enterprise.context.ApplicationScoped;
import javax.sql.DataSource;
import java.sql.Connection;

@ApplicationScoped
public class JasperReportGenerateService {
    private final DataSource dataSource;

    public JasperReportGenerateService(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public void generatePdfReport(String jasperReportPath, String outputFileName) throws Exception {
        JasperReport jasperReport = JasperCompileManager.compileReport(jasperReportPath);
        Connection connection = null;
        try {
            connection = dataSource.getConnection();
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, null, connection);
            JasperExportManager.exportReportToPdfFile(jasperPrint, outputFileName);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
