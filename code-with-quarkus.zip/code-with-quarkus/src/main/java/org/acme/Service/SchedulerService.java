package org.acme.Service;

import io.quarkus.scheduler.Scheduled;

import javax.inject.Inject;

public class SchedulerService {
    @Inject
    KebunService kebunService;

    @Scheduled(cron = "00 06 * * 6")
    void scheduledKebun(){ kebunService.postKebun(); }

    @Scheduled(cron = "00 06 31 * *")
    void scheduledPdfKebun() throws Exception{ kebunService.getKebunPdf(); }
}
