package org.acme.Service;

import org.acme.Model.Tgs7;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.transaction.Transactional;
import java.time.LocalDate;
@ApplicationScoped
public class KebunService {
    @Inject
    JasperReportGenerateService jasperReportGenerate;

    public void getKebunPdf() throws Exception {
        LocalDate pdfDate = LocalDate.now();
        String fileName = "LaporanKebun" + "_" + pdfDate.toString() + ".pdf";
        String outputFileName = "external_resources/generatedReport/" + fileName;
        String jasperReportPath = "external_resources/jasperReport/sample.jrxml";
        jasperReportGenerate.generatePdfReport(jasperReportPath, outputFileName);
    }
    @Transactional
    public void postKebun() {
        Tgs7 tgs7 = new Tgs7();
        LocalDate currentDate = LocalDate.now();

        tgs7.komoditas = "Tomat";
        tgs7.total = 500;
        tgs7.created_at = currentDate;
        tgs7.updated_at = currentDate;
        tgs7.persist();
    }
}
