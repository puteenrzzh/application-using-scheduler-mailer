package org.acme.Service;

import io.quarkus.mailer.MailTemplate;
import io.quarkus.qute.Location;
import io.quarkus.scheduler.Scheduled;
import io.smallrye.mutiny.Uni;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.io.File;
import java.time.LocalDate;

@ApplicationScoped
public class MailService {

    @Inject
    @Location("email")
    MailTemplate emailKebun;

    @Scheduled(cron = "00 07 31 * *")
    public Uni<Void> kirimMailKebun(){
        LocalDate pdfDate = LocalDate.now();
        return emailKebun.to("gonnaberich16@gmail.com")
                .subject("Report Monthly Farmer")
                .data("name", "Dengklek")
                .addAttachment("ReportFarmMonthly.pdf", new File("external_resources/generatedReport/LaporanKebun_"+pdfDate+".pdf"),"application/pdf")
                .send();
    }
}
