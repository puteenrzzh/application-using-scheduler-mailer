package org.acme.Controller;

import org.acme.Service.KebunService;

import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Path("kebun")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class KebunController {
    @Inject
    KebunService kebunService;
    @GET
    public void getPdf() throws Exception {
        kebunService.getKebunPdf();
    }
}
